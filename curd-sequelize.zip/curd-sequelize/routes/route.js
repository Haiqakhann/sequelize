import  express from "express";
const router = express.Router()
import {create,insert, read,edit,update,remove} from '../controller/userController.js'
import {book_create,book_insert} from '../controller/bookController.js'
// , read



router.route('/')
    .get(create)
    .post(insert)

router.route('/users')
    .get(read)

router.route('/edit/:name')
    .get(edit)
    .post(update)

router.route('/delete/:name')
    .get(remove)


router.route('/books')
    .get(book_create)
    .post(book_insert)

// router.route('/users')
//     .get(read)



export {router}