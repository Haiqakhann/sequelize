import { sequelize } from "../database/connection.js";
import { Sequelize } from 'sequelize';



const Books = sequelize.define('books', {
    book: Sequelize.STRING,
    author: {
        type:Sequelize.STRING,
        allowNull:false
    },
    publish_date: Sequelize.DATEONLY
});


export {Books}

  



