import { sequelize } from "../database/connection.js";
import { Sequelize } from 'sequelize';



const users = sequelize.define('users', {
    name: Sequelize.STRING,
    email: Sequelize.STRING,
    password: Sequelize.STRING
});


export {users}

  



