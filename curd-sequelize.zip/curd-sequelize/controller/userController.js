import { Sequelize } from 'sequelize';
import { users } from "../model/user.js";
import { sequelize } from "../database/connection.js";
const queryInterface = sequelize.getQueryInterface();

const create = async(req,res)=> {
  queryInterface.createTable('users', {
        id: {
          type: Sequelize.INTEGER,
          autoIncrement: true,
          primaryKey: true
        },
        name: Sequelize.STRING,
        email: Sequelize.STRING,
        password: Sequelize.STRING,
    });
  res.render('../views/index.ejs')     
}


const insert = async(req,res)=> {
    const name = req.body.username
    const email = req.body.email
    const password = req.body.password

    await users.create({
        name: name,
        email :email,
        password:password
      });        
    res.redirect('/users')            
}

const read = async(req,res)=> {
    const Users = await users.findAll();
    res.render('../views/view.ejs',{Users})    
}


const edit = async(req,res)=> {
    const user = await users.findOne({where:{name:req.params.name}});
    res.render('../views/edit.ejs',{user})
}

const update = async(req,res)=> {
    const oldname = req.params.name
    // updated data
    const name = req.body.name
    const email = req.body.email
    const password = req.body.password
    await users.update({ name:name,email:email,password:password }, {
        where: {
          name:oldname
        },
      });
    res.redirect('/users')            
}

const remove = async(req,res)=> {
    const name = req.params.name
    await users.destroy({
        where: {
          name:name
        },
      })
    res.redirect('/users')
}
export {create,insert,read,edit,update,remove}