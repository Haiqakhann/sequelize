import { Sequelize } from 'sequelize';
import { users } from "../model/user.js";
import { Books } from "../model/book.js";
import { sequelize } from "../database/connection.js";
const queryInterface = sequelize.getQueryInterface();

const book_create = async(req,res)=> {
  queryInterface.createTable('books', {
    id: {
      type: Sequelize.INTEGER,
      autoIncrement: true,
      primaryKey: true
    },
    book: Sequelize.STRING,
    author:{
      type: Sequelize.STRING,
      allowNull:false
    },
    publish_date: Sequelize.DATEONLY
});

  const Users = await users.findAll();
  res.render('../views/books/addbook.ejs',{Users})     

}


const book_insert = async(req,res)=> {
  Books.belongsTo(users);

  const user=req.body.users
  const book = req.body.book
  const author = req.body.author
  const publishdate = req.body.date

  const User = await users.findOne({where:{name:user}})
  console.log(User)
  await Books.create({
    book: book,
    author : author,
    publish_date: publishdate ,
    User
  },
    {
      include: [ users ]    // include a data dependency
    }
  );
  
  res.send('books') 
  // res.redirect('/users')            
}

const read = async(req,res)=> {
    // const Users = await users.findAll();
    // res.render('../views/view.ejs',{Users})    
}



export {book_create,book_insert,read}