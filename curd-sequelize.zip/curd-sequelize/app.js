import Express  from "express";
const app = Express()

import {connectDB} from './database/connection.js'  
import { router } from "./routes/route.js";
const port = 3000

app.set('view engine','ejs')

connectDB()

app.use(Express.urlencoded({extended:true}))
app.use(Express.static('public'))




app.use('/',router)

app.listen(port,()=>console.log('server is running'))